## DATA ANALYSIS ON HOTEL BOOKING.

This dataset was gotten from FestMan on LinkedIn.

Importing of necessary libraries that would be used


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```

We have to import our data that we have to analysis. the data is in excel format


```python
hotel=pd.read_excel(r'Desktop/Hostel Booking Challenge_FestMan.xlsx')
hotel.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Booking ID</th>
      <th>Date of Booking</th>
      <th>Year</th>
      <th>Time</th>
      <th>Customer ID</th>
      <th>Gender</th>
      <th>Age</th>
      <th>Origin Country</th>
      <th>State</th>
      <th>Location</th>
      <th>...</th>
      <th>Hotel Name</th>
      <th>Hotel Rating</th>
      <th>Payment Mode</th>
      <th>Bank Name</th>
      <th>No. Of Days.1</th>
      <th>Rooms.1</th>
      <th>Booking Price[SGD]</th>
      <th>Discount</th>
      <th>GST</th>
      <th>Profit Margin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>DDMY00001</td>
      <td>2010-01-01</td>
      <td>2010</td>
      <td>10:49:40</td>
      <td>MY00001</td>
      <td>Male</td>
      <td>42</td>
      <td>Malaysia</td>
      <td>Johor</td>
      <td>Iskandar Puteri</td>
      <td>...</td>
      <td>Hotel Triton</td>
      <td>4.3</td>
      <td>Wallet</td>
      <td>United Overseas Bank (UOB)</td>
      <td>8</td>
      <td>1</td>
      <td>243</td>
      <td>0.01</td>
      <td>0.07</td>
      <td>0.25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>DDID00002</td>
      <td>2010-01-01</td>
      <td>2010</td>
      <td>09:19:47</td>
      <td>ID00001</td>
      <td>Female</td>
      <td>44</td>
      <td>Indonesia</td>
      <td>Ciawi</td>
      <td>West Java</td>
      <td>...</td>
      <td>Enchanted Isle</td>
      <td>4.2</td>
      <td>Wallet</td>
      <td>EZ-Link</td>
      <td>1</td>
      <td>2</td>
      <td>312</td>
      <td>0.00</td>
      <td>0.07</td>
      <td>0.24</td>
    </tr>
    <tr>
      <th>2</th>
      <td>DDSG00003</td>
      <td>2010-01-01</td>
      <td>2010</td>
      <td>11:52:56</td>
      <td>SG00001</td>
      <td>Female</td>
      <td>31</td>
      <td>Singapore</td>
      <td>Central</td>
      <td>Rochor</td>
      <td>...</td>
      <td>Seacoast Hotel</td>
      <td>4.5</td>
      <td>Credit Card</td>
      <td>Grab</td>
      <td>7</td>
      <td>2</td>
      <td>338</td>
      <td>0.19</td>
      <td>0.07</td>
      <td>0.20</td>
    </tr>
    <tr>
      <th>3</th>
      <td>DDSG00004</td>
      <td>2010-01-01</td>
      <td>2010</td>
      <td>13:44:40</td>
      <td>SG00002</td>
      <td>Male</td>
      <td>28</td>
      <td>Singapore</td>
      <td>North</td>
      <td>Yishun</td>
      <td>...</td>
      <td>Night In Paradise</td>
      <td>4.2</td>
      <td>Debit Card</td>
      <td>DBS Paylah</td>
      <td>4</td>
      <td>2</td>
      <td>254</td>
      <td>0.19</td>
      <td>0.07</td>
      <td>0.13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>DDKH00005</td>
      <td>2010-01-01</td>
      <td>2010</td>
      <td>05:38:26</td>
      <td>KH00001</td>
      <td>Male</td>
      <td>44</td>
      <td>Cambodia</td>
      <td>Phnom Trop</td>
      <td>Pursat</td>
      <td>...</td>
      <td>Tiny Digs Hotel</td>
      <td>4.6</td>
      <td>Wallet</td>
      <td>Bank of Singapore (BOS)</td>
      <td>3</td>
      <td>3</td>
      <td>313</td>
      <td>0.15</td>
      <td>0.07</td>
      <td>0.17</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 27 columns</p>
</div>




```python
hotel.columns
```




    Index(['Booking ID', 'Date of Booking', 'Year', 'Time', 'Customer ID',
           'Gender', 'Age', 'Origin Country', 'State', 'Location',
           'Destination Country', 'Destination City', 'No. Of People',
           'Check-in date', 'No. Of Days', 'Check-Out Date', 'Rooms', 'Hotel Name',
           'Hotel Rating', 'Payment Mode', 'Bank Name', 'No. Of Days.1', 'Rooms.1',
           'Booking Price[SGD]', 'Discount', 'GST', 'Profit Margin'],
          dtype='object')




```python
5+4
```




    9




```python
hotel.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 66535 entries, 0 to 66534
    Data columns (total 27 columns):
     #   Column               Non-Null Count  Dtype         
    ---  ------               --------------  -----         
     0   Booking ID           66535 non-null  object        
     1   Date of Booking      66535 non-null  datetime64[ns]
     2   Year                 66535 non-null  int64         
     3   Time                 66535 non-null  object        
     4   Customer ID          66535 non-null  object        
     5   Gender               66535 non-null  object        
     6   Age                  66535 non-null  int64         
     7   Origin Country       66535 non-null  object        
     8   State                66535 non-null  object        
     9   Location             66535 non-null  object        
     10  Destination Country  66535 non-null  object        
     11  Destination City     66535 non-null  object        
     12  No. Of People        66535 non-null  int64         
     13  Check-in date        66535 non-null  datetime64[ns]
     14  No. Of Days          66535 non-null  int64         
     15  Check-Out Date       66535 non-null  datetime64[ns]
     16  Rooms                66535 non-null  int64         
     17  Hotel Name           66535 non-null  object        
     18  Hotel Rating         66535 non-null  float64       
     19  Payment Mode         66535 non-null  object        
     20  Bank Name            66535 non-null  object        
     21  No. Of Days.1        66535 non-null  int64         
     22  Rooms.1              66535 non-null  int64         
     23  Booking Price[SGD]   66535 non-null  int64         
     24  Discount             66535 non-null  float64       
     25  GST                  66535 non-null  float64       
     26  Profit Margin        66535 non-null  float64       
    dtypes: datetime64[ns](3), float64(4), int64(8), object(12)
    memory usage: 13.7+ MB
    


```python
hotel.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Age</th>
      <th>No. Of People</th>
      <th>No. Of Days</th>
      <th>Rooms</th>
      <th>Hotel Rating</th>
      <th>No. Of Days.1</th>
      <th>Rooms.1</th>
      <th>Booking Price[SGD]</th>
      <th>Discount</th>
      <th>GST</th>
      <th>Profit Margin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>66535.000000</td>
      <td>66535.000000</td>
      <td>66535.000000</td>
      <td>66535.000000</td>
      <td>66535.000000</td>
      <td>66535.000000</td>
      <td>66535.000000</td>
      <td>66535.000000</td>
      <td>66535.000000</td>
      <td>66535.000000</td>
      <td>6.653500e+04</td>
      <td>66535.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2015.132396</td>
      <td>38.436402</td>
      <td>3.995852</td>
      <td>3.233787</td>
      <td>2.283400</td>
      <td>4.288508</td>
      <td>3.233787</td>
      <td>2.283400</td>
      <td>214.054212</td>
      <td>0.125473</td>
      <td>7.000000e-02</td>
      <td>0.188815</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.885649</td>
      <td>11.556566</td>
      <td>2.000116</td>
      <td>3.377939</td>
      <td>1.031154</td>
      <td>0.275520</td>
      <td>3.377939</td>
      <td>1.031154</td>
      <td>108.127280</td>
      <td>0.075115</td>
      <td>2.774191e-14</td>
      <td>0.052766</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2010.000000</td>
      <td>19.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>3.300000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>35.000000</td>
      <td>0.000000</td>
      <td>7.000000e-02</td>
      <td>0.100000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2013.000000</td>
      <td>28.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>4.200000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>125.000000</td>
      <td>0.060000</td>
      <td>7.000000e-02</td>
      <td>0.140000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2015.000000</td>
      <td>38.000000</td>
      <td>4.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>4.300000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>199.000000</td>
      <td>0.130000</td>
      <td>7.000000e-02</td>
      <td>0.200000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2018.000000</td>
      <td>48.000000</td>
      <td>6.000000</td>
      <td>4.000000</td>
      <td>3.000000</td>
      <td>4.500000</td>
      <td>4.000000</td>
      <td>3.000000</td>
      <td>293.000000</td>
      <td>0.190000</td>
      <td>7.000000e-02</td>
      <td>0.230000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2019.000000</td>
      <td>58.000000</td>
      <td>7.000000</td>
      <td>97.000000</td>
      <td>4.000000</td>
      <td>4.700000</td>
      <td>97.000000</td>
      <td>4.000000</td>
      <td>578.000000</td>
      <td>0.250000</td>
      <td>7.000000e-02</td>
      <td>0.300000</td>
    </tr>
  </tbody>
</table>
</div>




```python
hotel.shape
```




    (66535, 27)




```python
hotel.isna().sum()
```




    Booking ID             0
    Date of Booking        0
    Year                   0
    Time                   0
    Customer ID            0
    Gender                 0
    Age                    0
    Origin Country         0
    State                  0
    Location               0
    Destination Country    0
    Destination City       0
    No. Of People          0
    Check-in date          0
    No. Of Days            0
    Check-Out Date         0
    Rooms                  0
    Hotel Name             0
    Hotel Rating           0
    Payment Mode           0
    Bank Name              0
    No. Of Days.1          0
    Rooms.1                0
    Booking Price[SGD]     0
    Discount               0
    GST                    0
    Profit Margin          0
    dtype: int64




```python
hotel1=hotel.pivot_table(index=['Gender'], values='Booking Price[SGD]',aggfunc='count')
```


```python
def count_rows(rows):
    return len(rows)
x=hotel.groupby('State').apply(count_rows)
x
```




    State
    Albay            238
    An Lao           255
    Andong Teuk      134
    Angkor Borei     139
    Angkor Chum      123
                    ... 
    Waibakul         158
    West            2617
    Yala             414
    Yogyakarta       151
    Zambales          78
    Length: 219, dtype: int64




```python
hotel1=hotel.pivot_table(index=['Origin Country'], values='Gender',aggfunc='count')
```


```python
hotel.columns
```




    Index(['Booking ID', 'Date of Booking', 'Year', 'Time', 'Customer ID',
           'Gender', 'Age', 'Origin Country', 'State', 'Location',
           'Destination Country', 'Destination City', 'No. Of People',
           'Check-in date', 'No. Of Days', 'Check-Out Date', 'Rooms', 'Hotel Name',
           'Hotel Rating', 'Payment Mode', 'Bank Name', 'No. Of Days.1', 'Rooms.1',
           'Booking Price[SGD]', 'Discount', 'GST', 'Profit Margin'],
          dtype='object')




```python
hotel1.plot(kind='bar', figsize=(10,5))
```




    <AxesSubplot:xlabel='Origin Country'>




    
![png](output_15_1.png)
    



```python
def count_rows(rows):
    return len(rows)
x=hotel.groupby('Gender').apply(count_rows)
x
```




    Gender
    Female    33387
    Male      33148
    dtype: int64




```python
hotel.columns
```




    Index(['Booking ID', 'Date of Booking', 'Year', 'Time', 'Customer ID',
           'Gender', 'Age', 'Origin Country', 'State', 'Location',
           'Destination Country', 'Destination City', 'No. Of People',
           'Check-in date', 'No. Of Days', 'Check-Out Date', 'Rooms', 'Hotel Name',
           'Hotel Rating', 'Payment Mode', 'Bank Name', 'No. Of Days.1', 'Rooms.1',
           'Booking Price[SGD]', 'Discount', 'GST', 'Profit Margin'],
          dtype='object')




```python
x=hotel.drop_duplicates(['Origin Country'])
```


```python
print(x['Destination Country'])
```

    0      Denmark
    1     Colombia
    2      Germany
    4        Kenya
    5       Canada
    12       Italy
    17      Brazil
    Name: Destination Country, dtype: object
    


```python
booking=hotel.copy()
```


```python
booking
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Booking ID</th>
      <th>Date of Booking</th>
      <th>Year</th>
      <th>Time</th>
      <th>Customer ID</th>
      <th>Gender</th>
      <th>Age</th>
      <th>Origin Country</th>
      <th>State</th>
      <th>Location</th>
      <th>...</th>
      <th>Hotel Name</th>
      <th>Hotel Rating</th>
      <th>Payment Mode</th>
      <th>Bank Name</th>
      <th>No. Of Days.1</th>
      <th>Rooms.1</th>
      <th>Booking Price[SGD]</th>
      <th>Discount</th>
      <th>GST</th>
      <th>Profit Margin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>DDMY00001</td>
      <td>2010-01-01</td>
      <td>2010</td>
      <td>10:49:40</td>
      <td>MY00001</td>
      <td>Male</td>
      <td>42</td>
      <td>Malaysia</td>
      <td>Johor</td>
      <td>Iskandar Puteri</td>
      <td>...</td>
      <td>Hotel Triton</td>
      <td>4.3</td>
      <td>Wallet</td>
      <td>United Overseas Bank (UOB)</td>
      <td>8</td>
      <td>1</td>
      <td>243</td>
      <td>0.01</td>
      <td>0.07</td>
      <td>0.25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>DDID00002</td>
      <td>2010-01-01</td>
      <td>2010</td>
      <td>09:19:47</td>
      <td>ID00001</td>
      <td>Female</td>
      <td>44</td>
      <td>Indonesia</td>
      <td>Ciawi</td>
      <td>West Java</td>
      <td>...</td>
      <td>Enchanted Isle</td>
      <td>4.2</td>
      <td>Wallet</td>
      <td>EZ-Link</td>
      <td>1</td>
      <td>2</td>
      <td>312</td>
      <td>0.00</td>
      <td>0.07</td>
      <td>0.24</td>
    </tr>
    <tr>
      <th>2</th>
      <td>DDSG00003</td>
      <td>2010-01-01</td>
      <td>2010</td>
      <td>11:52:56</td>
      <td>SG00001</td>
      <td>Female</td>
      <td>31</td>
      <td>Singapore</td>
      <td>Central</td>
      <td>Rochor</td>
      <td>...</td>
      <td>Seacoast Hotel</td>
      <td>4.5</td>
      <td>Credit Card</td>
      <td>Grab</td>
      <td>7</td>
      <td>2</td>
      <td>338</td>
      <td>0.19</td>
      <td>0.07</td>
      <td>0.20</td>
    </tr>
    <tr>
      <th>3</th>
      <td>DDSG00004</td>
      <td>2010-01-01</td>
      <td>2010</td>
      <td>13:44:40</td>
      <td>SG00002</td>
      <td>Male</td>
      <td>28</td>
      <td>Singapore</td>
      <td>North</td>
      <td>Yishun</td>
      <td>...</td>
      <td>Night In Paradise</td>
      <td>4.2</td>
      <td>Debit Card</td>
      <td>DBS Paylah</td>
      <td>4</td>
      <td>2</td>
      <td>254</td>
      <td>0.19</td>
      <td>0.07</td>
      <td>0.13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>DDKH00005</td>
      <td>2010-01-01</td>
      <td>2010</td>
      <td>05:38:26</td>
      <td>KH00001</td>
      <td>Male</td>
      <td>44</td>
      <td>Cambodia</td>
      <td>Phnom Trop</td>
      <td>Pursat</td>
      <td>...</td>
      <td>Tiny Digs Hotel</td>
      <td>4.6</td>
      <td>Wallet</td>
      <td>Bank of Singapore (BOS)</td>
      <td>3</td>
      <td>3</td>
      <td>313</td>
      <td>0.15</td>
      <td>0.07</td>
      <td>0.17</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>66530</th>
      <td>DDSG66531</td>
      <td>2019-12-31</td>
      <td>2019</td>
      <td>23:36:16</td>
      <td>SG12034</td>
      <td>Female</td>
      <td>42</td>
      <td>Singapore</td>
      <td>Central</td>
      <td>Orchard</td>
      <td>...</td>
      <td>Silver Cloud Inn</td>
      <td>4.3</td>
      <td>Wallet</td>
      <td>Grab</td>
      <td>4</td>
      <td>2</td>
      <td>182</td>
      <td>0.23</td>
      <td>0.07</td>
      <td>0.24</td>
    </tr>
    <tr>
      <th>66531</th>
      <td>DDSG66532</td>
      <td>2019-12-31</td>
      <td>2019</td>
      <td>14:41:01</td>
      <td>SG12035</td>
      <td>Female</td>
      <td>54</td>
      <td>Singapore</td>
      <td>Central</td>
      <td>Geylang</td>
      <td>...</td>
      <td>The Elet</td>
      <td>4.2</td>
      <td>COD</td>
      <td>DBS Paylah</td>
      <td>4</td>
      <td>2</td>
      <td>125</td>
      <td>0.06</td>
      <td>0.07</td>
      <td>0.19</td>
    </tr>
    <tr>
      <th>66532</th>
      <td>DDSG66533</td>
      <td>2019-12-31</td>
      <td>2019</td>
      <td>19:11:16</td>
      <td>SG12036</td>
      <td>Female</td>
      <td>57</td>
      <td>Singapore</td>
      <td>Central</td>
      <td>Downtown Core</td>
      <td>...</td>
      <td>The Elet</td>
      <td>4.4</td>
      <td>Debit Card</td>
      <td>EZ-Link</td>
      <td>1</td>
      <td>4</td>
      <td>318</td>
      <td>0.02</td>
      <td>0.07</td>
      <td>0.22</td>
    </tr>
    <tr>
      <th>66533</th>
      <td>DDTH66534</td>
      <td>2019-12-31</td>
      <td>2019</td>
      <td>05:12:29</td>
      <td>TH12170</td>
      <td>Female</td>
      <td>44</td>
      <td>Thailand</td>
      <td>Surat Thani</td>
      <td>Ko Samui</td>
      <td>...</td>
      <td>Sunset Lodge</td>
      <td>4.2</td>
      <td>Debit Card</td>
      <td>HSBC</td>
      <td>1</td>
      <td>2</td>
      <td>173</td>
      <td>0.14</td>
      <td>0.07</td>
      <td>0.25</td>
    </tr>
    <tr>
      <th>66534</th>
      <td>DDVN66535</td>
      <td>2019-12-31</td>
      <td>2019</td>
      <td>00:51:52</td>
      <td>VN05959</td>
      <td>Female</td>
      <td>52</td>
      <td>Vietnam</td>
      <td>Pleiku</td>
      <td>Gia Lai</td>
      <td>...</td>
      <td>Coastal bay hotel</td>
      <td>4.3</td>
      <td>Internet Banking</td>
      <td>Grab</td>
      <td>4</td>
      <td>3</td>
      <td>182</td>
      <td>0.17</td>
      <td>0.07</td>
      <td>0.24</td>
    </tr>
  </tbody>
</table>
<p>66535 rows × 27 columns</p>
</div>




```python

```
